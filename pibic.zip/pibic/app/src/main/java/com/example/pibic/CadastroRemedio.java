package com.example.pibic;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.pibic.dao.AppDatabase;
import com.example.pibic.dao.Remedio_dao;
import com.example.pibic.model.MyAdapter;
import com.example.pibic.model.RecyclerViewInterface;
import com.example.pibic.model.Remedio;

import java.util.ArrayList;
import java.util.List;

public class CadastroRemedio extends AppCompatActivity implements RecyclerViewInterface {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastro_remedio);

        RecyclerView recyclerView = findViewById(R.id.recyclerRemedios);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Remedio> remedios = new ArrayList<>();

        AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "remedios").build();

        Remedio_dao dao = db.remedioDao();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    remedios.addAll(dao.listar());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            MyAdapter adapter = new MyAdapter(getApplicationContext(), remedios, CadastroRemedio.this);
                            recyclerView.setAdapter(adapter);
                        }
                    });
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }).start();
    }



    public void voltar(View view){
        finish();
    }

    @Override
    public void onItemClick(int position) {

    }

    public void selecionarRemedio(View view) {
        RecyclerView recyclerView = findViewById(R.id.recyclerRemedios);
        if (recyclerView.getVisibility() == View.GONE) {
            recyclerView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.GONE);
        }
    }
}
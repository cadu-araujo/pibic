package com.example.pibic.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pibic.R;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {

    private final RecyclerViewInterface recyclerViewInterface;

    private final Context context;
    private final List<Remedio> remedios;

    public MyAdapter(Context context, List<Remedio> remedios, RecyclerViewInterface recyclerViewInterface) {
        this.context = context;
        this.remedios = remedios;
        this.recyclerViewInterface = recyclerViewInterface; // Inicializa o terceiro parâmetro
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_remedio,parent,false), recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.nameView.setText(remedios.get(position).getNome());
        holder.descricaoView.setText(remedios.get(position).getDescricao());
        holder.imageView.setImageResource(remedios.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return remedios.size();
    }
}

package com.example.pibic.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "ubs")
public class UBS {
    @PrimaryKey(autoGenerate = true)
    public int ubsid;

    @ColumnInfo(name = "ubsbome")
    public String nome;

    @ColumnInfo(name = "ubscnes")
    public String cnes;

    @ColumnInfo(name = "ubsrua")
    public String rua;

    @ColumnInfo(name = "ubsnum")
    public int numero;

    @ColumnInfo(name = "ubsbairro")
    public String bairro;
}

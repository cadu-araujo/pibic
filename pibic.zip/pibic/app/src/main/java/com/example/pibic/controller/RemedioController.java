package com.example.pibic.controller;

import com.example.pibic.model.Remedio;

import java.util.ArrayList;
import java.util.List;

public class RemedioController {

}

package com.example.pibic.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import com.example.pibic.model.Usuario;

@Entity(
        tableName = "login",
        foreignKeys = {
                @ForeignKey(entity = Usuario.class, parentColumns = "usuarioid", childColumns = "usuario_usuarioid"),
                @ForeignKey(entity = UBS.class, parentColumns = "ubsid", childColumns = "ubs_ubsid1")
        },
        indices = {@Index(value = "logemail", unique = true), @Index("usuario_usuarioid"), @Index("ubs_ubsid1")}
)
public class Login {
    @PrimaryKey(autoGenerate = true)
    public int logid;

    @ColumnInfo(name = "logemail")
    public String email;

    @ColumnInfo(name = "logsenha")
    public String senha;

    @ColumnInfo(name = "usuario_usuarioid")
    public Integer usuarioId;

    @ColumnInfo(name = "ubs_ubsid1")
    public Integer ubsId;
}

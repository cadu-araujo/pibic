package com.example.pibic.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import com.example.pibic.model.Login_model;

@Dao
public interface Login_dao {
    @Query("SELECT * FROM Login_model")
    List<Login_model> listar();

    @Query("SELECT * FROM Login_model WHERE logemail = :email LIMIT 1")
    Login_model getLoginByEmail(String email);

    @Insert
    void insert(Login_model... loginModels);

    @Delete
    void delete(Login_model loginModel);
}

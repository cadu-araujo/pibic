package com.example.pibic.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import com.example.pibic.model.Login;

@Dao
public interface Login_dao {
    @Query("SELECT * FROM Login")
    List<Login> listar();

    @Insert
    void insert(Login...logins);

    @Delete
    void delete(Login login);
}

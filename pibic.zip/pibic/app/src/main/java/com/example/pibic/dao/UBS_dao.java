package com.example.pibic.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import com.example.pibic.model.UBS;

@Dao
public interface UBS_dao {
    @Query("SELECT * FROM UBS")
    List<UBS> listar();

    @Query("SELECT ubsid FROM UBS WHERE ubscnes LIKE :cnes")
    Integer buscaCnes(String cnes);

    @Insert
    void insert(UBS...ubs);

    @Delete
    void delete(UBS ubs);

    @Insert
    void insertAll(List<UBS> ubsList);

    @Query("DELETE FROM UBS")
    void deletarTodas();
}

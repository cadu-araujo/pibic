package com.example.pibic;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.pibic.dao.AppDatabase;
import com.example.pibic.dao.Usuario_dao;
import com.example.pibic.model.Usuario;

import java.util.List;

public class listagem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_listagem);
    }

    public void carregar(View view){
        LinearLayout lnlUsers = findViewById(R.id.lnlUser);
        lnlUsers.removeAllViews();

        new Thread(new Runnable() {
            @Override
            public void run() {
                AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "usuarios").build();
                Usuario_dao user_d = db.usuarioDao();

                List<Usuario> users = user_d.listar();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        for (Usuario u: users){
                            TextView t = new TextView(listagem.this);
                            t.setText(u.nome);
                            lnlUsers.addView(t);
                        }
                    }
                });
            }
        }).start();
    }
    public void voltar (View view){
        finish();
    }
}
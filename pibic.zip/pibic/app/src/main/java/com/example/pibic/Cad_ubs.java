package com.example.pibic;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import com.example.pibic.dao.AppDatabase;
import com.example.pibic.dao.Login_dao;
import com.example.pibic.dao.UBS_dao;
import com.example.pibic.dao.Usuario_dao;
import com.example.pibic.model.Login_model;
import com.example.pibic.model.UBS;

public class Cad_ubs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.cad_ubs);
    }

    public void voltar (View v) {
        finish();
    }

    public void cadastrar (View view){
        EditText nome = findViewById(R.id.nomeUBS);
        EditText cnes = findViewById(R.id.cnesUBS);
        EditText endereco = findViewById(R.id.enderecoUBS);
        EditText email = findViewById(R.id.emailUBS);
        EditText senha = findViewById(R.id.senhaUBS);

        UBS ubs = new UBS();
        Login_model log = new Login_model();

        if(nome.getText().toString().equals("") || cnes.getText().toString().equals("") || endereco.getText().toString().equals("") || email.getText().toString().equals("") || senha.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        }else{
            ubs.nome = nome.getText().toString();
            ubs.cnes = cnes.getText().toString();
            ubs.ubsendereco = endereco.getText().toString();

            log.email = email.getText().toString();
            log.senha = senha.getText().toString();

           try {
               new Thread(new Runnable() {
                   @Override
                   public void run() {
                       AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "app_database").build();
                       UBS_dao dao = db.UBS_dao();
                       Login_dao l_dao = db.Login_dao();

                       dao.insert(ubs);

                       int id = dao.buscaCnes(cnes.getText().toString());
                       log.ubsId = id;
                       l_dao.insert(log);

                       runOnUiThread(new Runnable() {
                           @Override
                           public void run() {
                               AlertDialog.Builder builder = new AlertDialog.Builder(Cad_ubs.this);
                               builder.setMessage("UBS cadastrada");
                               builder.create().show();
                           }
                       });
                   }
               }).start();
           }catch (Exception ex){
               ex.printStackTrace();
           }
        }
        zera(nome, cnes, endereco, email, senha);
    }

    public void zera(EditText nome, EditText cnes, EditText endereco, EditText email, EditText senha) {
        nome.requestFocus();
        nome.setText("");
        cnes.setText("");
        endereco.setText("");
        email.setText("");
        senha.setText("");
    }


}
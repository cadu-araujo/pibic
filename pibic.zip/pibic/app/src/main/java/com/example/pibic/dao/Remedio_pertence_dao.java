package com.example.pibic.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import com.example.pibic.model.RemedioPertence;

@Dao
public interface Remedio_pertence_dao {
    @Query("SELECT * FROM Remedio_pertence")
    List<RemedioPertence> listar();

    @Insert
    void insert(RemedioPertence...remedios);

    @Delete
    void delete(RemedioPertence rp);
}

package com.example.pibic.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;


import com.example.pibic.model.Usuario;

@Dao
public interface Usuario_dao {

    @Query("SELECT * FROM Usuario")
    public List<Usuario> listar();

    @Insert
    public void insert(Usuario...usuarios);

    @Delete
    public void delete(Usuario users);

}

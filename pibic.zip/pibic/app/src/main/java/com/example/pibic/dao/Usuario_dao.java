package com.example.pibic.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;


import com.example.pibic.model.Usuario;

@Dao
public interface Usuario_dao {

    @Query("SELECT * FROM Usuario")
    public List<Usuario> listar();

    @Query("SELECT usuarioid FROM usuario WHERE usuariocpf LIKE :cpf")
    Integer buscaCpf(String cpf);

    @Insert
    public void insert(Usuario...usuarios);

    @Delete
    public void delete(Usuario users);

}

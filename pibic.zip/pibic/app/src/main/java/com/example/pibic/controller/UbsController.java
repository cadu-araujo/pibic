package com.example.pibic.controller;

public class UbsController {
}

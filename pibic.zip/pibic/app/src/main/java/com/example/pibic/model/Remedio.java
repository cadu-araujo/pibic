package com.example.pibic.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.Date;

@Entity
public class Remedio {

    @PrimaryKey(autoGenerate = true)
    public int rem_id;

    @ColumnInfo(name="Nome")
    public String nome;

    @ColumnInfo(name = "remvalidade")
    @TypeConverters({DateConverter.class})
    public Date validade;
}

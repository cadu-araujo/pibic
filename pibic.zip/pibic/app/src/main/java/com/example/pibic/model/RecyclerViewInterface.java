package com.example.pibic.model;

public interface RecyclerViewInterface {
    public void onItemClick(int position);
}

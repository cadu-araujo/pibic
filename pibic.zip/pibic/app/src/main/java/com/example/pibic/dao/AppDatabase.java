package com.example.pibic.dao;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.pibic.model.Login;
import com.example.pibic.model.Remedio;
import com.example.pibic.model.RemedioPertence;
import com.example.pibic.model.UBS;
import com.example.pibic.model.Usuario;

@Database(entities = {Login.class, Remedio.class, RemedioPertence.class, UBS.class, Usuario.class}, version = 2)
public abstract class AppDatabase extends RoomDatabase {
    public abstract Remedio_dao remedioDao();
    public abstract Usuario_dao usuarioDao();
    public abstract UBS_dao UBS_dao();
    public abstract Login_dao Login_dao();
    public abstract Remedio_pertence_dao Remedio_pertence_dao();
}

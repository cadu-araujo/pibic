package com.example.pibic;
import android.view.View;

import android.os.Bundle;

import java.text.ParseException;
import java.util.Locale;

import android.widget.EditText;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.Date;


import com.example.pibic.dao.AppDatabase;
import com.example.pibic.dao.Login_dao;
import com.example.pibic.dao.Usuario_dao;
import com.example.pibic.model.Login_model;
import com.example.pibic.model.Usuario;

public class Cad_usu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.cad_usu);
    }

    public void voltar (View view) {
        finish();
    }

    public void cadastrarUsuario (View view) throws ParseException {
        EditText nome = findViewById(R.id.nomeUser);
        EditText cpf = findViewById(R.id.cpfUser);
        EditText dtnasc = findViewById(R.id.dtnUser);
        EditText endereco = findViewById(R.id.enderecoUser);

        EditText email = findViewById(R.id.emailUser);
        EditText senha = findViewById(R.id.senhaUser);

        Usuario user = new Usuario();
        Login_model log = new Login_model();

        if (nome.getText().toString().equals("") || cpf.getText().toString().equals("") || dtnasc.getText().toString().equals("") || endereco.getText().toString().equals("") ||email.getText().toString().equals("") || email.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        } else {
            user.nome = nome.getText().toString();
            user.cpf = cpf.getText().toString();
            user.usu_endereco = endereco.getText().toString();

            String dt_nasc = dtnasc.getText().toString();
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date dataNascimento = formato.parse(dt_nasc);

            user.dataNascimento = dataNascimento;

            log.email = email.getText().toString();
            log.senha = senha.getText().toString();

            try {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "app_database").build();
                        Usuario_dao dao = db.usuarioDao();
                        Login_dao l_dao = db.Login_dao();

                        dao.insert(user);

                        int id = dao.buscaCpf(cpf.getText().toString());
                        log.usuarioId = id;
                        l_dao.insert(log);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                AlertDialog.Builder builder = new AlertDialog.Builder(Cad_usu.this);
                                builder.setMessage("Usuário criado");
                                builder.create().show();

                            }
                        });
                    }
                }).start();
            }catch (Exception ex) {
               ex.printStackTrace();

            }
        }
        zera(nome, cpf, dtnasc, endereco, email, senha);
    }

    public void zera(EditText nome, EditText cpf, EditText dtnasc, EditText endereco, EditText email, EditText senha) {
        nome.requestFocus();
        nome.setText("");
        cpf.setText("");
        dtnasc.setText("");
        endereco.setText("");
        email.setText("");
        senha.setText("");
    }


}
package com.example.pibic;
import android.view.View;
import android.content.Intent;
import android.os.Bundle;

import java.text.ParseException;
import java.util.Locale;

import android.widget.EditText;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.Date;


import com.example.pibic.dao.AppDatabase;
import com.example.pibic.dao.Usuario_dao;
import com.example.pibic.model.Usuario;


public class Cad_usu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.cad_usu);
    }

    public void voltar (View view) {
        finish();
    }

    public void cadastrarUsuario (View view) throws ParseException {
        EditText nome = findViewById(R.id.nomeUser);
        EditText cpf = findViewById(R.id.cpfUser);
        EditText dtnasc = findViewById(R.id.dtnUser);
        EditText endereco = findViewById(R.id.enderecoUser);

        EditText email = findViewById(R.id.emailUser);
        EditText senha = findViewById(R.id.senhaUser);

        Usuario user = new Usuario();

        if (nome.getText().toString().equals("") || cpf.getText().toString().equals("") || dtnasc.getText().toString().equals("") || endereco.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        } else {
            user.nome = nome.getText().toString();
            user.cpf = cpf.getText().toString();
            user.usu_endereco = endereco.getText().toString();

            String dt_nasc = dtnasc.getText().toString();
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date dataNascimento = formato.parse(dt_nasc);

            user.dataNascimento = dataNascimento;

            try {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "usuarios").build();
                        Usuario_dao dao = db.usuarioDao();

                        dao.insert(user);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                AlertDialog.Builder builder = new AlertDialog.Builder(Cad_usu.this);
                                builder.setMessage("Salvo com sucesso");
                                builder.create().show();
                            }
                        });
                    }
                }).start();
            }catch (Exception ex) {
               ex.printStackTrace();
            }
        }
    }

}
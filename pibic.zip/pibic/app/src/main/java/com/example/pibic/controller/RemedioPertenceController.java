package com.example.pibic.controller;

public class RemedioPertenceController {
}

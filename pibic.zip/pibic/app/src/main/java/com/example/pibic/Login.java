package com.example.pibic;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import javax.crypto.Mac;

public class Login extends AppCompatActivity {

    private EditText login_email, login_senha;

    private TextView login_alerta;
    private Button logar, btn_login_home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login);

        logar = findViewById(R.id.btn_logar);
        btn_login_home = findViewById(R.id.btn_login_home);
        login_email = findViewById(R.id.login_email);
        login_senha = findViewById(R.id.login_senha);
        login_alerta = findViewById(R.id.login_alerta);



        logar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = login_email.getText().toString().trim();
                String senha = login_senha.getText().toString().trim();

                if (login_email.getText().toString().equals("") || login_senha.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                    return;
                } else {

                    if(login_email.getText().toString().equals("ubs@123") && login_senha.getText().toString().equals("ubspadrao")) {
                        Intent intent = new Intent(getApplicationContext(), Opcoes_ubs.class);
                        startActivity(intent);
                        return;
                    }
                    if(login_email.getText().toString().equals("user@123") && login_senha.getText().toString().equals("userpadrao")){
                        Intent intent = new Intent(getApplicationContext(), Opcoes_user.class);
                        startActivity(intent);
                        return;
                    }else{
                        Toast.makeText(getApplicationContext(), "Login inválido", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

            }
        });

        btn_login_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.btn_user_vol), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
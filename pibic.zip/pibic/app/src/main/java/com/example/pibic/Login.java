package com.example.pibic;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.pibic.dao.AppDatabase;
import com.example.pibic.dao.Login_dao;
import com.example.pibic.model.Login_model;


public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login);
    }

    public void voltar(View view) {
        finish();
    }

    public void login(String email, String senha) {
        try {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "app_database").build();

                    Login_dao l_dao = db.Login_dao();
                    Login_model login = new Login_model();
                    login = l_dao.getLoginByEmail(email);

                    if (login == null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
                                builder.setMessage("Login inválido");
                                builder.create().show();
                            }
                        });
                    } else if (!login.senha.equals(senha)) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
                                builder.setMessage("Senha inválida");
                                builder.create().show();
                            }
                        });
                    } else {
                        if (login.usuarioId != null) {
                            Intent i = new Intent(getApplicationContext(), Opcoes_user.class);
                            startActivity(i);
                        } else if (login.ubsId != null) {
                            Intent i = new Intent(getApplicationContext(), Opcoes_ubs.class);
                            startActivity(i);
                        }
                    }
                }
            }).start();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    public void logar(View view) {
        EditText login_email = findViewById(R.id.login_email);
        EditText login_senha = findViewById(R.id.login_senha);

        String email = login_email.getText().toString();
        String senha = login_senha.getText().toString();

        if (email.equals("") || senha.equals("")) {
            Toast.makeText(getApplicationContext(), "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        } else {
            if (login_email.getText().toString().equals("ubs@123") && login_senha.getText().toString().equals("ubspadrao")) {
                Intent intent = new Intent(getApplicationContext(), Opcoes_ubs.class);
                startActivity(intent);
                return;
            }
            if (login_email.getText().toString().equals("user@123") && login_senha.getText().toString().equals("userpadrao")) {
                Intent intent = new Intent(getApplicationContext(), Opcoes_user.class);
                startActivity(intent);
                return;
            } else {
                login(email, senha);
            }
        }
        zera(login_email, login_senha);
    }

    public void zera(EditText login_email, EditText login_senha) {
        login_email.setText("");
        login_email.requestFocus();
        login_senha.setText("");
    }
}
package com.example.pibic.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

@Entity(
        tableName = "remedio_pertence",
        primaryKeys = {"rem_per_rem", "rem_per_ubs"},
        foreignKeys = {
                @ForeignKey(entity = Remedio.class, parentColumns = "rem_id", childColumns = "rem_per_rem"),
                @ForeignKey(entity = UBS.class, parentColumns = "ubsid", childColumns = "rem_per_ubs")
        },
        indices = {@Index("rem_per_rem"), @Index("rem_per_ubs")}
)
public class RemedioPertence {
    @ColumnInfo(name = "rem_per_rem")
    public int remedioId;

    @ColumnInfo(name = "rem_per_ubs")
    public int ubsId;

    @ColumnInfo(name = "quantidade")
    public int quantidade;
}

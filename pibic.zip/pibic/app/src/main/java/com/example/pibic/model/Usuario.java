package com.example.pibic.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.Date;

@Entity(tableName = "usuario")
public class Usuario {
    @PrimaryKey(autoGenerate = true)
    public int usuarioid;

    @ColumnInfo(name = "usuarionome")
    public String nome;

    @ColumnInfo(name = "usuariocpf")
    public String cpf;

    @ColumnInfo(name = "usuariodtnasc")
    @TypeConverters({DateConverter.class})
    public Date dataNascimento;

    @ColumnInfo(name = "usuarioendereco")
    public String usu_endereco;
}

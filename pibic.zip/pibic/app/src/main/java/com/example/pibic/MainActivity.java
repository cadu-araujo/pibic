package com.example.pibic;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.pibic.dao.AppDatabase;
import com.example.pibic.dao.Remedio_dao;
import com.example.pibic.dao.UBS_dao;
import com.example.pibic.model.Remedio;
import com.example.pibic.model.UBS;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        criaRemedios();
        criaUBS();
    }

    public void login(View view) {
        Intent intent = new Intent(getApplicationContext(), Login.class);
        startActivity(intent);
    }

    public void cadastrar(View view) {
        Intent intent = new Intent(getApplicationContext(), Opcoes_cad.class);
        startActivity(intent);
    }

    public void criaRemedios() {
        deletarTodosRemedios();
        List<Remedio> remedios = new ArrayList<>();
        adicionarRemedios(remedios);
        inserirRemediosNoBanco(remedios);
    }

    private void adicionarRemedios(List<Remedio> remedios) {
        Remedio r;
        r = new Remedio();
        r.nome = "Albendazol";
        r.descricao = "Trata vermes e parasitas.";
        r.image = R.drawable.albendazol;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Amoxilina";
        r.descricao = "Antibiótico para infecções bacterianas.";
        r.image = R.drawable.amoxilina;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Atenolol";
        r.descricao = "Tratamento para hipertensão e arritmia.";
        r.image = R.drawable.atenolol;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Azitromicina";
        r.descricao = "Antibiótico para infecções respiratórias.";
        r.image = R.drawable.azitromicina;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Diclofenaco";
        r.descricao = "Anti-inflamatório para dor muscular.";
        r.image = R.drawable.diclofenaco;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Dipirona";
        r.descricao = "Analgésico e antipirético para febre.";
        r.image = R.drawable.dipirona;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Glibenclamida";
        r.descricao = "Controla glicose em diabéticos.";
        r.image = R.drawable.glibenclamida;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Ibuprofeno";
        r.descricao = "Anti-inflamatório para dor e febre.";
        r.image = R.drawable.ibuprofeno;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Miconazol";
        r.descricao = "Antifúngico para infecções cutâneas.";
        r.image = R.drawable.miconazol;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Omeprazol";
        r.descricao = "Trata refluxo e úlceras gástricas.";
        r.image = R.drawable.omeprazol;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Paracetamol";
        r.descricao = "Alivia dores e febre.";
        r.image = R.drawable.paracetamol;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Sinvastantina";
        r.descricao = "Reduz colesterol no sangue.";
        r.image = R.drawable.sinvastantina;
        remedios.add(r);

        r = new Remedio();
        r.nome = "Timolol";
        r.descricao = "Colírio para glaucoma ocular.";
        r.image = R.drawable.timolol;
        remedios.add(r);

    }

    private void inserirRemediosNoBanco(List<Remedio> remedios) {
        new Thread(() -> {

            db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "ubs").build();
            Remedio_dao dao = db.remedioDao();
            try {
                dao.insertAll(remedios);
                runOnUiThread(() -> mostrarDialogo("Remédios criados com sucesso"));
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> mostrarDialogo("Erro ao criar remédios"));
            }
        }).start();
    }

    public void criaUBS() {
        deletarTodasUBS();
        List<UBS> ubsList = new ArrayList<>();
        adicionarUBS(ubsList);
        inserirUBSNoBanco(ubsList);
    }

    private void adicionarUBS(List<UBS> ubsList) {
        UBS u;

        u = new UBS();
        u.nome = "UBS Balbina Mestrinho";
        u.cnes = "6487408";
        u.ubsendereco = "Av. Autaz Mirim, 155, São José Operário, Manaus, AM";
        ubsList.add(u);

        u = new UBS();
        u.nome = "UBS Sálvio Belota";
        u.cnes = "7035429";
        u.ubsendereco = "Av. Grande Circular, 5, São José Operário, Manaus, AM";
        ubsList.add(u);

        u = new UBS();
        u.nome = "UBS Alfredo Campos";
        u.cnes = "6736867";
        u.ubsendereco = "Rua Penetração II, Cidade Nova, Manaus, AM";
        ubsList.add(u);

        u = new UBS();
        u.nome = "UBS Armando Mendes";
        u.cnes = "7093840";
        u.ubsendereco = "Rua Rio Andirá, Armando Mendes, Manaus, AM";
        ubsList.add(u);

        u = new UBS();
        u.nome = "UBS Leonor Brilhante";
        u.cnes = "7062941";
        u.ubsendereco = "Rua Paracuúba, Monte das Oliveiras, Manaus, AM";
        ubsList.add(u);
    }

    private void inserirUBSNoBanco(List<UBS> ubsList) {
        new Thread(() -> {
            db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "remedios").build();

            UBS_dao dao = db.UBS_dao();
            try {
                dao.insertAll(ubsList);
                runOnUiThread(() -> mostrarDialogo("UBSs criadas com sucesso"));
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> mostrarDialogo("Erro ao criar UBSs"));
            }
        }).start();
    }


    public void deletarTodasUBS() {
        new Thread(() -> {
            db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "ubs").build();

            UBS_dao dao = db.UBS_dao();
            try {
                dao.deletarTodas();
                runOnUiThread(() -> mostrarDialogo("UBSs deletadas com sucesso"));
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> mostrarDialogo("Erro ao deletar UBSs"));
            }
        }).start();
    }

    public void deletarTodosRemedios() {
        new Thread(() -> {
            db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "remedios").build();
            Remedio_dao dao = db.remedioDao();
            try {
                dao.deletarTodos();
                runOnUiThread(() -> mostrarDialogo("Remédios deletados com sucesso"));
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> mostrarDialogo("Erro ao deletar remédios"));
            }
        }).start();
    }

    private void mostrarDialogo(String mensagem) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage(mensagem).setPositiveButton("OK", null).create().show();
    }
}

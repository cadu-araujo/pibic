package DAO;


import androidx.room.Dao;
import androidx.room.Query;
import androidx.room.Insert;
import androidx.room.Delete;

import java.util.List;

import model.Remedio;

@Dao
public interface Remedio_dao {

    @Query("SELECT * FROM Remedio")
    List<Remedio> listar();

    @Insert
    void insert(Remedio...remedios);

    @Delete
    void delete(Remedio remedios);
}

package DAO;

import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import model.Remedio_pertence;

public interface Remedio_pertence_dao {
    @Query("SELECT * FROM Remedio_pertence")
    List<Remedio_pertence> listar();

    @Insert
    void insert(Remedio_pertence...remedios);

    @Delete
    void delete(Remedio_pertence rp);
}

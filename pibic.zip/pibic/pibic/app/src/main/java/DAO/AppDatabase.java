package DAO;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import model.Login;
import model.Remedio;
import model.Remedio_pertence;
import model.UBS;
import model.Usuario;

@Database(entities = {Remedio.class, UBS.class, Login.class, Remedio_pertence.class, Usuario.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract Remedio_dao remedioDao();
}

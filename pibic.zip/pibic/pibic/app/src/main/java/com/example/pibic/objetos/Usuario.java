package com.example.pibic.objetos;

public class Usuario {

}

package model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity
public class Usuario {
    @PrimaryKey(autoGenerate = true)
    int usu_id;
    @ColumnInfo
    String usu_nome;
    @ColumnInfo
    Date usu_dtnasc;
    @ColumnInfo
    String cpf;
    @ColumnInfo
    String usu_endereco;

    public int getUsu_id() {
        return usu_id;
    }

    public void setUsu_id(int usu_id) {
        this.usu_id = usu_id;
    }

    public String getUsu_nome() {
        return usu_nome;
    }

    public void setUsu_nome(String usu_nome) {
        this.usu_nome = usu_nome;
    }

    public Date getUsu_dtnasc() {
        return usu_dtnasc;
    }

    public void setUsu_dtnasc(Date usu_dtnasc) {
        this.usu_dtnasc = usu_dtnasc;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getUsu_endereco() {
        return usu_endereco;
    }

    public void setUsu_endereco(String usu_endereco) {
        this.usu_endereco = usu_endereco;
    }
}

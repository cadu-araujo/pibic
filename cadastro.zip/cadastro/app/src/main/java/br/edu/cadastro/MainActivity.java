package br.edu.cadastro;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private LinearLayout formUBS;
    private LinearLayout formUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando os componentes após o setContentView
        radioGroup = findViewById(R.id.radioGroup);
        formUBS = findViewById(R.id.form_ubs);
        formUser = findViewById(R.id.form_usuario);

        // Setando o listener para o RadioGroup
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // Verificando qual rádio foi selecionado
                if (checkedId == R.id.radio_ubs) {
                    formUBS.setVisibility(View.VISIBLE);
                    formUser.setVisibility(View.GONE);
                } else if (checkedId == R.id.radio_usuario) {
                    formUBS.setVisibility(View.GONE);
                    formUser.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}

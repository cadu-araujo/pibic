package DAO;

import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;


import model.Usuario;

public interface Usuario_dao {
    @Query("SELECT * FROM Usuario")
    List<Usuario> listar();

    @Insert
    void insert(Usuario...usuarios);

    @Delete
    void delete(Usuario users);
}

package DAO;

import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import model.Login;
import model.Remedio;

public interface Login_dao {
    @Query("SELECT * FROM Login")
    List<Login> listar();

    @Insert
    void insert(Login...logins);

    @Delete
    void delete(Login login);
}

package model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class UBS {
    @PrimaryKey(autoGenerate = true)
    int ubs_id;
    @ColumnInfo
    String ubs_CNES;
    @ColumnInfo
    String ubs_nome;
    @ColumnInfo
    String ubs_endereco;

    public int getUbs_id() {
        return ubs_id;
    }

    public void setUbs_id(int ubs_id) {
        this.ubs_id = ubs_id;
    }

    public String getUbs_CNES() {
        return ubs_CNES;
    }

    public void setUbs_CNES(String ubs_CNES) {
        this.ubs_CNES = ubs_CNES;
    }

    public String getUbs_nome() {
        return ubs_nome;
    }

    public void setUbs_nome(String ubs_nome) {
        this.ubs_nome = ubs_nome;
    }

    public String getUbs_endereco() {
        return ubs_endereco;
    }

    public void setUbs_endereco(String ubs_endereco) {
        this.ubs_endereco = ubs_endereco;
    }
}

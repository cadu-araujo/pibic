package model;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(foreignKeys = { @ForeignKey(
        entity = UBS.class,
        parentColumns = "ubs_id",
        childColumns = "rp_ubs_id",
        onDelete = ForeignKey.CASCADE),
        @ForeignKey(
                entity = Remedio.class,
                parentColumns = "rem_id",
                childColumns = "rp_remedio_id",
                onDelete = ForeignKey.CASCADE
        )}
)
public class Remedio_pertence {
@PrimaryKey
    int rp_id;
    int rp_ubs_id;
    int rp_remedio_id;
    @ColumnInfo
    int quantidade;

    public int getRp_ubs_id() {
        return rp_ubs_id;
    }

    public void setRp_ubs_id(int rp_ubs_id) {
        this.rp_ubs_id = rp_ubs_id;
    }

    public int getRp_remedio_id() {
        return rp_remedio_id;
    }

    public void setRp_remedio_id(int rp_remedio_id) {
        this.rp_remedio_id = rp_remedio_id;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
}

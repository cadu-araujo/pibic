package com.example.pibic;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class Cadastro extends AppCompatActivity {

    private RadioGroup radioGroup;
    private LinearLayout formUBS;
    private LinearLayout formUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        radioGroup = findViewById(R.id.radioGroup);
        formUBS = findViewById(R.id.form_ubs);
        formUser = findViewById(R.id.form_usuario);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio_ubs) {
                    formUBS.setVisibility(View.VISIBLE);
                    formUser.setVisibility(View.GONE);
                } else if (checkedId == R.id.radio_usuario) {
                    formUBS.setVisibility(View.GONE);
                    formUser.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}

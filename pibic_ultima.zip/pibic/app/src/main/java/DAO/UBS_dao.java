package DAO;

import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import model.UBS;

public interface UBS_dao {
    @Query("SELECT * FROM UBS")
    List<UBS> listar();

    @Insert
    void insert(UBS...ubs);

    @Delete
    void delete(UBS ubs);
}

package com.example.pibic.objetos;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import DAO.Login_dao;
import DAO.Remedio_dao;
import DAO.Remedio_pertence_dao;
import DAO.UBS_dao;
import DAO.Usuario_dao;
import model.Login;
import model.Remedio;
import model.Remedio_pertence;
import model.UBS;

@Database(entities = {Remedio.class, Login.class, Remedio_pertence.class, UBS.class, Usuario.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    public abstract Login_dao Login_dao();
    public abstract Remedio_dao Remedio_dao();
    public abstract Remedio_pertence_dao Remedio_pertence_dao();
    public abstract UBS_dao UBS_dao();

    public abstract Usuario_dao Usuario_dao();

}
